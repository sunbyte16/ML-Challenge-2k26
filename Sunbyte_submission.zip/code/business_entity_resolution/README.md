# Amazon ML Challenge 2026: Business Entity Resolution MVP

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12-blue.svg)](https://www.python.org/downloads/)
[![Tests](https://img.shields.io/badge/tests-11%2F11%20passing-brightgreen.svg)](tests/)
[![Validator](https://img.shields.io/badge/Official%20Validator-PASS-success.svg)](utils/validate_submission.py)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

Production-grade, competition-focused solution for the **Amazon ML Challenge 2026 — Business Entity Resolution Challenge**.

[Contributing Guidelines](CONTRIBUTING.md) • [Code of Conduct](CODE_OF_CONDUCT.md) • [Methodology Document](Documentation_template.md) • [License](LICENSE)

---

## 1. Problem Overview

In large-scale commercial platforms, business identity data arrives from multiple independent sources, each contributing partial, noisy fragments of information about the same real-world entities.

The challenge involves three independent data sources:
* **Source 1**: The deduplicated reference source.
* **Source 2**: Noisy business records.
* **Source 3**: Noisy business records.

### Objective
For every Source 1 entity, identify all matching records from Source 2 and Source 3.
A Source 1 entity may match:
* **Zero records** (singleton entity)
* **One record**
* **Multiple records**

The system does not assume 1-to-1 matching and avoids false merges.

---

## 2. Dataset Structure

All datasets are tab-separated (`.tsv`) files:

```text
dataset/
├── train/
│   ├── train_source1.tsv       # Deduplicated reference records (US, India)
│   ├── train_source2.tsv       # Noisy records
│   ├── train_source3.tsv       # Noisy records
│   └── train_ground_truth.tsv  # S1 -> matched target IDs
│
└── test/
    ├── test_source1.tsv        # Test reference records (US, India, France)
    ├── test_source2.tsv        # Test noisy records
    └── test_source3.tsv        # Test noisy records
```

### Columns
* **Sources (1, 2, 3)**: `entity_id`, `business_name`, `business_address`, `country`
* **Ground Truth**: `source1_entity_id`, `matched_entity_ids`

### Critical Country Rule
Training data contains records from **US** and **India**. The test set additionally introduces **France**. Country is treated as an open-set string feature and never filtered or hardcoded.

---

## 3. Architecture & Pipeline

```text
RAW TSV FILES
      ↓
DATA LOADER & PROFILING (sep="\t", strict dtypes, null handling)
      ↓
TEXT NORMALIZATION (NFKD unicode, lowercasing, legal suffix unification, address expansions)
      ↓
MULTI-PASS BLOCKING (Exact Name, Name 1/2 Prefixes, Address Prefix, Composite Keys, TF-IDF Fallback)
      ↓
HARD NEGATIVE MINING (Candidates from blocking buckets not in ground truth)
      ↓
PAIRWISE FEATURE EXTRACTION (RapidFuzz string similarities, token Jaccards, char 3-grams, open-set country)
      ↓
ML MATCH CLASSIFIER (HistGradientBoosting / LightGBM / LogisticRegression with balanced weights)
      ↓
PROBABILITY SCORING P(match)
      ↓
THRESHOLD OPTIMIZATION (Maximizes entity-level macro F0.5)
      ↓
SINGLETON & MULTI-MATCH DECISION LOGIC
      ↓
OUTPUT GENERATION (matching_results.tsv, candidate_pairs.tsv)
      ↓
OFFICIAL VALIDATOR CHECK (utils/validate_submission.py)
```

---

## 4. Preprocessing & Normalization

1. **Business Name**:
   * NFKD decomposition + ASCII encoding.
   * Lowercasing and whitespace normalization.
   * Common punctuation and separator normalization (`&` → `and`, `@` → `at`).
   * Legal suffix unification (`Private Limited` / `Pvt Ltd` / `pvt. ltd.` → `pvt ltd`).
2. **Business Address**:
   * Standard road/building abbreviations normalized (`st` → `street`, `rd` → `road`, `ave` → `avenue`).
   * Numeric house/building numbers preserved.
3. **Country**:
   * Open-set mapping: common country synonyms normalized (`US`/`USA` → `us`, `IN`/`IND` → `india`, `FR`/`FRA` → `france`).
   * Unseen countries pass through seamlessly.

---

## 5. Blocking & Candidate Generation

Candidate generation achieves high recall while reducing Cartesian space by >99%:
* **Block A**: Exact normalized business name.
* **Block B**: First token of business name (length $\ge 3$).
* **Block C**: First two tokens of business name.
* **Block D**: Name prefix + Address prefix composite key.
* **Block E**: Country + Name prefix composite key.
* **Block F**: TF-IDF character $n$-gram cosine similarity retrieval for low-candidate entities.

*Constraints*: Candidates only come from Source 2 and Source 3 (never S1 → S1). Hard cap of 150 candidates per S1 entity.

---

## 6. Pairwise Features

For every candidate pair $(S_1, \text{Target})$:
* **Name Metrics**: Levenshtein Ratio, Partial Ratio, Token Sort Ratio, Token Set Ratio, Token Jaccard, Length Diff, Length Ratio, Token Count Diff, Exact Match, Substring Match, Same First Token, Shared Token Count/Ratio, Char 3-gram Jaccard.
* **Address Metrics**: Ratio, Partial Ratio, Token Sort Ratio, Token Set Ratio, Token Jaccard, Length Diff, Length Ratio, Token Count Diff, Exact Match, Substring Match, Same First Token, Shared Token Count/Ratio, Char 3-gram Jaccard.
* **Country Features**: `country_exact_match` (1 if exact string match, 0 otherwise), `country_missing` (1 if either empty).
* **Metadata**: Target source indicator (`target_is_s2`, `target_is_s3`), presence flags.

---

## 7. Model & Evaluation Metric

### Classifier
* Primary model: `HistGradientBoostingClassifier(class_weight="balanced", max_depth=6, learning_rate=0.05)`
* Baselines: `LogisticRegression(class_weight="balanced")`, `LGBMClassifier`

### Official Metric: Entity-Level Macro $F_{0.5}$
Precision is weighted higher than recall ($\beta = 0.5$):

$$F_{0.5} = \frac{(1 + 0.5^2) \times \text{Precision} \times \text{Recall}}{0.5^2 \times \text{Precision} + \text{Recall}} = \frac{1.25 \times \text{Precision} \times \text{Recall}}{0.25 \times \text{Precision} + \text{Recall}}$$

* **Singleton Rule**:
  * If true set is empty and predicted set is empty: score = **1.0** (full credit).
  * If true set is empty and predicted set has a match: score = **0.0** (penalty for false merge).
* Evaluated per Source 1 entity and macro-averaged across all entities.

---

## 8. Usage Instructions

### 1. Installation
```bash
pip install -r requirements.txt
```

### 2. Run Exploratory Data Analysis
```bash
python -m business_entity_resolution.pipeline --mode eda
```

### 3. Train Classifier & Optimize Threshold
```bash
python -m business_entity_resolution.pipeline --mode train
```

### 4. Predict on Test Set & Generate Submission Files
```bash
python -m business_entity_resolution.pipeline --mode predict
```

### 5. Run Full End-to-End Pipeline
```bash
python -m business_entity_resolution.pipeline --mode all
```

### 6. Run Submission Validator
```bash
python utils/validate_submission.py --matching output/matching_results.tsv --candidate output/candidate_pairs.tsv --test-dir dataset/test
```

### 7. Run Unit Tests
```bash
pytest tests/ -v
```

---

## 9. Submission Package Structure

```text
<team_name>_submission.zip
├── output/
│   ├── matching_results.tsv   # Official test matches (evaluated on leaderboard)
│   └── candidate_pairs.tsv    # Final candidate set passed to model
├── code/
│   └── business_entity_resolution/
│       ├── src/
│       ├── tests/
│       ├── utils/
│       ├── requirements.txt
│       └── README.md
└── Documentation_template.md  # Detailed methodology document
```
